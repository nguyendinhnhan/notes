//
//  ___FILENAME___
//  ___PROJECTNAME___
//
//  Created by ___FULLUSERNAME___ on ___DATE___.
//  Copyright © ___YEAR___ NFQ. All rights reserved.
//

import Foundation
import UIKit

protocol ___VARIABLE_productName___RoutingLogic {
    func routeToNext()
}

class ___FILEBASENAMEASIDENTIFIER___:  ___VARIABLE_productName___RoutingLogic {
    
    weak var viewController: ___VARIABLE_productName___ViewController?
    var viewModel: ___VARIABLE_productName___ViewModel?

    func routeToNext() {
        // add route to next viewcontroller according to viewModel
    }
}

extension ___FILEBASENAMEASIDENTIFIER___ {

}