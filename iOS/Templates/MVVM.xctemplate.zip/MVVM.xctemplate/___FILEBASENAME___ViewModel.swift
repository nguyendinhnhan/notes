//
//  ___FILENAME___
//  ___PROJECTNAME___
//
//  Created by ___FULLUSERNAME___ on ___DATE___.
//  Copyright © ___YEAR___ NFQ. All rights reserved.
//


import Foundation

protocol ___FILEBASENAMEASIDENTIFIER___Protocol {
    func viewModelDidLoad()
    func viewModelWillAppear()
}


class ___FILEBASENAMEASIDENTIFIER___:  ___FILEBASENAMEASIDENTIFIER___Protocol {	

    var service: ___VARIABLE_productName___ServiceProtocol

    init(with service: ___VARIABLE_productName:identifier___ServiceProtocol) {
        self.service = service
    }
    
	  
    func viewModelDidLoad() {
        
    }
    
    func viewModelWillAppear() {
        
    }
    
}