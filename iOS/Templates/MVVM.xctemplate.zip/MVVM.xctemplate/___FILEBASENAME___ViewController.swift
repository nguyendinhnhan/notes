//
//  ___FILENAME___
//  ___PROJECTNAME___
//
//  Created by ___FULLUSERNAME___ on ___DATE___.
//  Copyright © ___YEAR___ NFQ. All rights reserved.
//

import UIKit

class ___FILEBASENAMEASIDENTIFIER___: UIViewController {

    private var viewModel: ___VARIABLE_productName:identifier___ViewModel?
    private var router: ___VARIABLE_productName:identifier___Router?
   
    override func viewDidLoad() {
        super.viewDidLoad()
        setUp()
    }

    private func setUp() {
        viewModel?.viewModelDidLoad()
        let router = ___VARIABLE_productName___Router()
        self.router = router
        router.viewController = self
        router.viewModel = viewModel
    }
    
    override func viewWillAppear(_ animated: Bool) {
        super.viewWillAppear(animated)
        viewModel?.viewModelWillAppear()
    }
}
