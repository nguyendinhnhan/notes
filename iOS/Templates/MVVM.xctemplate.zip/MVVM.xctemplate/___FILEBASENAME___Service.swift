//
//  ___FILENAME___
//  ___PROJECTNAME___
//
//  Created by ___FULLUSERNAME___ on ___DATE___.
//  Copyright © ___YEAR___ NFQ. All rights reserved.
//

import UIKit


protocol ___FILEBASENAMEASIDENTIFIER___Protocol {
    func loadData()
}


class ___VARIABLE_productName___Service: ___FILEBASENAMEASIDENTIFIER___Protocol {
    
    func loadData() {

    }
}
