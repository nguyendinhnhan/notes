//
//  ___FILENAME___
//  ___PROJECTNAME___
//
//  Created by ___FULLUSERNAME___ on ___DATE___.
//  Copyright © ___YEAR___ NFQ. All rights reserved.
//

import UIKit

protocol ___VARIABLE_productName___RoutingLogic {
    func routeToNext()
}

protocol ___VARIABLE_productName___DataPassing {
    var dataStore: ___VARIABLE_productName___DataStore? { get }
}

class ___VARIABLE_productName___Router: NSObject, ___VARIABLE_productName___RoutingLogic, ___VARIABLE_productName___DataPassing {

    // MARK: - Properties

    weak var viewController: ___VARIABLE_productName___ViewController?
    var dataStore: ___VARIABLE_productName___DataStore?

    // MARK: - Routing

    func routeToNext() {
        
    }

}
