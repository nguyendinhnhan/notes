//
//  ___FILENAME___
//  ___PROJECTNAME___
//
//  Created by ___FULLUSERNAME___ on ___DATE___.
//  Copyright © ___YEAR___ NFQ. All rights reserved.
//

import UIKit

protocol ___VARIABLE_productName___BusinessLogic {
    func fetch___VARIABLE_productName___(with request: ___VARIABLE_productName___Models.Fetch___VARIABLE_productName___.Request)
}

protocol ___VARIABLE_productName___DataStore {
    var exampleVariable: String? { get set }
}

class ___VARIABLE_productName___Interactor: ___VARIABLE_productName___BusinessLogic, ___VARIABLE_productName___DataStore {

    typealias Models = ___VARIABLE_productName___Models

    lazy var worker = ___VARIABLE_productName___Worker()
    var presenter: ___VARIABLE_productName___PresentationLogic?

    var exampleVariable: String?

    func fetch___VARIABLE_productName___(with request: ___VARIABLE_productName___Models.Fetch___VARIABLE_productName___.Request) {
        let response = Models.Fetch___VARIABLE_productName___.Response()
        presenter?.present___VARIABLE_productName___(with: response)
    }
}
