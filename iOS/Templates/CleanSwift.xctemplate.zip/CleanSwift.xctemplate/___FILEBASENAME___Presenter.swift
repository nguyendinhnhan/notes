//
//  ___FILENAME___
//  ___PROJECTNAME___
//
//  Created by ___FULLUSERNAME___ on ___DATE___.
//  Copyright © ___YEAR___ NFQ. All rights reserved.
//

import UIKit

protocol ___VARIABLE_productName___PresentationLogic {
    func present___VARIABLE_productName___(with response: ___VARIABLE_productName___Models.Fetch___VARIABLE_productName___.Response)
}

class ___VARIABLE_productName___Presenter: ___VARIABLE_productName___PresentationLogic {

    typealias Models = ___VARIABLE_productName___Models
    weak var viewController: ___VARIABLE_productName___DisplayLogic?

    func present___VARIABLE_productName___(with response: ___VARIABLE_productName___Models.Fetch___VARIABLE_productName___.Response) {
        
    }
}
