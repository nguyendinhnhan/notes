//
//  ___FILENAME___
//  ___PROJECTNAME___
//
//  Created by ___FULLUSERNAME___ on ___DATE___.
//  Copyright © ___YEAR___ NFQ. All rights reserved.
//

import UIKit

class ___VARIABLE_productName___Worker {


    typealias Models = ___VARIABLE_productName___Models

    // add necessary operations here
}
